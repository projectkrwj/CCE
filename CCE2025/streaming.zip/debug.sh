#!/bin/bash

qemu-system-x86_64 \
    -enable-kvm \
    -cpu host \
    -m 4096 \
    -smp 4 \
    -machine type=q35,accel=kvm \
    -drive file=windows.qcow2,if=none,id=disk0 \
    -device ahci,id=ahci \
    -device ide-hd,drive=disk0,bus=ahci.0 \
    -boot c \
    -vga qxl \
    -usb -device usb-tablet \
    -device virtio-serial \
    # -net nic,model=e1000 -net user