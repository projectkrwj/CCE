# streaming
해당 문제는 Windows Medium to SYSTEM LPE를 목표로 하는 문제입니다.
분석할 대상은 streaming.sys입니다.
`pow.py`, `pow_client.py`는 분석 대상이 아닙니다.
사전에 제공받은 압축 파일을 `PLEASE_CHANGE_ME_TO_windows.qcow2`와 교체해 주십시오.
실제 문제 디버깅과 풀이는 개인의 VM (Hyper-V, VirtualBox, VMware)를 이용하는 것을 권장합니다.

## Information
VM Image Download: https://cce2025-prob.s3.ap-northeast-2.amazonaws.com/image.7z

image.7z Password: c1d5b98a35d126c234639f1456f87987dfd18aae8b3091927d250f1a15bc03cb

Windows Version : Windows 11 26100.4946

### Hash
- sha256: FEAFA4166EF86E0943BA587062910C07FF527C6AE9F9AB873CE507B3B9904667  `image.7z`
- sha256: 476219606EC7501FCE4F4314159C11AC0E655DCABF27FF22AD0AABB16ADD3CCE  `windows.qcow2`
- sha256: 328AA76FF4809CE79BE78DB1E7DF8CD0FDFA2021BB32FAD7B15B9B83C3A7B808  `streaming.sys`

### Windows User
- cce / 2025

## How to Set Up Docker
```
docker compose up -d
```

### Set Up Kernel Debug Environment
```
bcdedit /set testsigning on
bcdedit /set debug on
```
### Load Driver
```
sc create cce binpath="/path/to/streaming.sys"
sc start cce
```

### Send Exploit
```
python3 pow_client.py /path/to/exploit.exe
```