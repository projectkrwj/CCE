from pwn import *
import hashlib
import argparse
import base64
import os

context.log_level = "debug"
HOST = "localhost"
PORT = 1339

def solve_pow(challenge, target):
    log.info(f"Solving PoW: challenge = {challenge}, target = {target}")
    for i in range(2**32):
        solution = i.to_bytes(4, "big").hex()
        full_challenge = bytes.fromhex(challenge + solution)
        hash_result = hashlib.sha256(full_challenge).hexdigest()
        if hash_result.startswith(target):
            log.success(f"Solution found: {solution}")
            return solution
    raise Exception("PoW solution not found")

def encode_exe_file(exe_path):
    """Read EXE file and encode it to base64"""
    if not os.path.exists(exe_path):
        raise FileNotFoundError(f"EXE file not found: {exe_path}")
    
    try:
        with open(exe_path, 'rb') as f:
            exe_content = f.read()
        
        # Validate it's a PE file (basic check)
        if len(exe_content) < 64 or exe_content[:2] != b'MZ':
            raise ValueError("File doesn't appear to be a valid Windows executable (missing MZ header)")
        
        # Check for PE signature
        pe_offset = int.from_bytes(exe_content[60:64], byteorder='little')
        if pe_offset >= len(exe_content) or exe_content[pe_offset:pe_offset+2] != b'PE':
            raise ValueError("File doesn't appear to be a valid PE executable (missing PE signature)")
        
        # Encode to base64
        base64_encoded = base64.b64encode(exe_content).decode('ascii')
        
        log.info(f"EXE file encoded successfully. Size: {len(exe_content)} bytes -> {len(base64_encoded)} base64 chars")
        return base64_encoded
    
    except Exception as e:
        raise Exception(f"Failed to encode EXE file: {str(e)}")

def main(exe_path):
    # Encode EXE file first
    try:
        encoded_exe = encode_exe_file(exe_path)
    except Exception as e:
        log.failure(f"Failed to process EXE file: {str(e)}")
        return
    
    conn = remote(HOST, PORT)
    log.info("Connected to server. Waiting for initial output...")
    
    # Receive initial output until challenge
    initial_output = conn.recvuntil(b"Challenge: ", drop=True)
    print(initial_output.decode())
    
    # Get challenge
    challenge = conn.recvline().strip().decode()
    log.info(f"Received challenge: {challenge}")
    
    # Get target
    conn.recvuntil(b"Target: ")
    target = conn.recvline().strip().decode()
    log.info(f"Received target: {target}")
    
    # Wait for solution prompt
    conn.recvuntil(b"Solution: ")
    
    # Solve PoW
    try:
        solution = solve_pow(challenge, target)
        log.info(f"Sending solution: {solution}")
        conn.sendline(solution.encode())
    except Exception as e:
        log.failure(f"Failed to solve PoW: {str(e)}")
        conn.close()
        return
    
    log.info("Waiting for server response...")
    
    # Wait for the prompt for EXE
    response = conn.recvuntil(b"Please enter the base64 encoded EXE file:", drop=True)
    print(response.decode())
    
    if b"Invalid Proof of Work solution" in response:
        log.failure("Failed to solve PoW. Exiting.")
        conn.close()
        return
    
    log.info("PoW verified successfully!")
    log.info(f"Sending base64 encoded EXE ({len(encoded_exe)} chars)...")
    
    # Send the base64 encoded EXE
    conn.sendline(encoded_exe.encode())
    
    log.info("EXE sent successfully. Switching to interactive mode to monitor execution...")
    
    # Switch to interactive mode to see the server responses
    conn.interactive()

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="PoW client for EXE execution challenge")
    parser.add_argument("exe_path", help="Path to the EXE file to execute")
    args = parser.parse_args()
    
    main(args.exe_path)

